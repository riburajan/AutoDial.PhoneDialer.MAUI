﻿
namespace PHDialer.Maui.Essentials.Services.PartialMethods
{
    public partial class PhoneDialer 
    {

        public partial void CallPhone(string number);

    }

}


