﻿using Android.Content;

namespace PHDialer.Maui.Essentials.Services.PartialMethods
{
    public partial class PhoneDialer
    {   
        public partial void CallPhone(string number)
        {

            Intent callIntent = new Intent(Intent.ActionCall);
            callIntent.SetFlags(ActivityFlags.NewTask);

            var url = Android.Net.Uri.Parse(string.Format("tel:{0}", number));
            callIntent.SetData(url);
            Android.App.Application.Context.StartActivity(callIntent);

        }

    }
}
