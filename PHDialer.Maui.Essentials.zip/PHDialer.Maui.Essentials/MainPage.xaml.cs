﻿
using PartialMethodsPhoneDialer = PHDialer.Maui.Essentials.Services.PartialMethods.PhoneDialer;

namespace PHDialer.Maui.Essentials
{
    public partial class MainPage : ContentPage
    {

/*

Sorry, I didn't say it more clearly. We should achieved PhoneDialer in Android platform,
the folder is Platforms->Android. 
And the namespace I replaced namespace   InvokePlatformCodeDemos.Platforms.Android 
with namespace InvokePlatformCodeDemos.Services.PartialMethods; 

Then we can refer to the PhoneDialer by 
using PartialMethodsPhoneDialer = InvokePlatformCodeDemos.Services.PartialMethods.PhoneDialer; 
while we refer to it in OurPage.xaml.cs. – 

*/



        public MainPage()
        {
            InitializeComponent();
        }

        private void OnDialButtonClicked(object sender, EventArgs e)
        {


            var dialer = new PartialMethodsPhoneDialer();
            dialer.CallPhone("123");


            //   Launcher.OpenAsync(new Uri("tel:" + txtNumber.Text));
            string number = txtNumber.Text; 

            try
            {
                //PhoneDialer.Open(number);
                if (PhoneDialer.Default.IsSupported)
                    PhoneDialer.Default.Open(number);
                else
                    DisplayAlert("Not Supporting", "Calling not supporting", "OK");
            }
            catch (ArgumentNullException ex)
            {
                DisplayAlert("ArgumentNullException", ex.Message, "OK");
            }
            catch (FeatureNotSupportedException ex)
            {
                // If Phone Dialer is not supported on this device.
                DisplayAlert("FeatureNotSupportedException", ex.Message, "OK");
            }
            catch (Exception ex)
            {
                DisplayAlert("Exception", ex.Message, "OK");
            }

        }


       


    }
}